SİYER DERS PAKETİ — 60 DERS
===========================

Peygamber Efendimiz (sallallahü aleyhi ve sellem)'in hayatını 5–8. sınıflar
için öğreten 60 ders bulunur. Her ders yaklaşık 10 dakikalık öğretim akışıdır.
Öğrencinin okuma, oyun ve konuşma süresi toplamı değiştirebilir.

BAŞLAMA
1. ZIP dosyasını tamamen bir klasöre çıkarın.
2. BASLA.html dosyasını Chrome, Edge, Firefox veya Safari ile açın.
3. Katalogdan bir ders seçip Bireysel düğmesiyle başlayın.
4. Anlatım sesi için derse başladıktan sonra ses düğmesini kullanın.
   Tarayıcılar ilk kullanıcı etkileşiminden önce sesi engelleyebilir.

Derslerin metinleri, SVG sahneleri, MP3 anlatımları, oyunları ve mevcut video
özetleri paketin içindedir. Bireysel kullanım internet gerektirmez. Kaynak
bağlantıları ve farklı cihazlar arasındaki canlı ders internet gerektirir.
Bazı tarayıcılar file:// altında kalıcı depolamayı veya video altyazısını
sınırlayabilir. İçerikler yine okunabilir; güvenilir kayıt ve bütün tarayıcı
özellikleri için paketi aşağıdaki gibi yerel ya da HTTPS sunucusunda açın.

YEREL SUNUCU
Python kurulu bir bilgisayarda paketin bulunduğu klasörde:
    python -m http.server 8000
Ardından:
    http://localhost:8000/

Kayıtlar kullanılan tarayıcının yerel deposunda tutulur. Aynı cihazda bile
başka tarayıcıya veya başka adrese geçince aynı kayıt görünmeyebilir.
Ders raporları: ders-odasi/rapor.html
Rapor ekranı sonuçları dışa aktarabilir. iframe ile gömmek tek başına LMS
not defterine otomatik bağlanma sağlamaz; aşağıdaki kayıt arayüzleri kullanılır.

LMS / WEB SİTESİNE EKLEME
Paketin bütün dosyalarını aynı dizin yapısıyla kendi sitenize yükleyin.
Örnek: https://okul.example/icerikler/siyer-paketi/
Bir dersin doğrudan adresi:
    ders-odasi/ders.html?d=siyer-01&rol=bireysel

Katalog iframe örneği (paketin okul sitenizdeki yolunu değiştirin):
    <iframe
      src="/icerikler/siyer-paketi/ders-odasi/siyer/index.html?embed=1"
      title="Siyer dersleri"
      style="width:100%;height:900px;border:0"
      allow="fullscreen; autoplay"
      allowfullscreen>
    </iframe>

Tek ders iframe örneği:
    <iframe
      src="/icerikler/siyer-paketi/ders-odasi/ders.html?d=siyer-01&rol=bireysel"
      title="Siyer dersi 1"
      style="width:100%;aspect-ratio:16/9;border:0"
      allow="fullscreen; autoplay"
      allowfullscreen>
    </iframe>

iframe üst sayfası mesaj alacaksa ders URL'sine URL-encoded host parametresi
ekleyin; örneğin &host=https%3A%2F%2Fokul.example. Motor postMessage ile
kaynak:'ders-odasi', tur:'hazir'|'ifade'|'durum'|'kapandi' mesajları gönderir.
Alıcı yalnız beklenen origin ve iframe.contentWindow kaynaklarını kabul
etmelidir. Puanın LMS'ye kaydedilmesi alıcı sistemin bu mesajları işlemesini
gerektirir. Motor erişilebilir SCORM 1.2/2004 API'sini de algılar; bu ZIP
web/iframe içerik paketi olarak hazırlanmıştır. LMS'nin SCORM içe aktarma
ekranında kullanmak için ayrıca o LMS'ye uygun manifest gerekir.

CANLI DERS
Katalogdaki öğretmen/öğrenci rolleri aynı ders ve oda koduyla kullanılır.
Farklı cihazların eşleşmesi için paketi HTTPS üzerinde barındırın ve kendi
canlı bağlantınızı kurun. İndirilen paketin ayarlar.js dosyasında Firebase
yapılandırması boş bırakılmıştır. Üretim sitesinin Firebase hesabı paketle
başka sunuculara taşınmaz. Kendi Firebase Realtime Database projenizde anonim
girişi, yetkili alan adlarını ve uygun erişim kurallarını yapılandırdıktan
sonra ders-odasi/ayarlar.js içindeki örnek alanları doldurun. Motor Firebase
istemcisini internetten yükler. Alternatif olarak motorun WebSocket veya LMS
postMessage canlı köprüsünü kullanabilirsiniz. Yayın öncesinde iki ayrı
cihazda öğretmen/öğrenci eşleşmesini deneyin. Aynı tarayıcı sekmeleri arasındaki
yerel deneme uzaktaki öğrencinin bağlandığını göstermez.
Yalnız ekran paylaşımıyla online anlatım için bireysel modu açıp ders ekranını
toplantı uygulamasında paylaşmak yeterlidir.

KLASÖRLER
- ders-odasi/siyer/: katalog, içerik metinleri, tema ve ortak görseller
- ders-odasi/dersler/siyer-01 ... siyer-60/: dersler ve yerel medya
- ders-odasi/motor/: Ders Odası oynatıcısı ve etkileşim motoru
- ders-odasi/rapor.html: yerel sonuçları görüntüleme
- paket-manifest.json: dosyaların byte boyutları ve SHA-256 özetleri

Bütün klasörü birlikte taşıyın. Dosya adlarını veya göreli yolları değiştirmek
görsellerin ve seslerin bulunamamasına neden olur. Bu ZIP kendi içinde ikinci
bir ZIP taşımaz; katalogdaki paket bağlantısı bu kullanım belgesini açar.

KAYNAKLAR VE KULLANIM
Her dersin kaynakları içerik dosyasında ve öğretmen görünümünde bulunur.
Kaynak sayfaları internet bağlantısıyla açılır. Kendi okulunuza ait öğrenci
verileri yerel raporlarla birlikte paylaşılmamalıdır.
