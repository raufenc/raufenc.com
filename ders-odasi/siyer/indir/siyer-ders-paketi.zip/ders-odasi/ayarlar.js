/* Bağımsız siyer paketi. Bireysel kullanım çevrimdışı çalışır.
Canlı ders için kendi Firebase projenizin web ayarlarını aşağıya ekleyin.
Kurulum ve canlı bağlantı seçenekleri: ../README.html */
window.DO_AYAR = window.DO_AYAR || {
  firebase: null
  /* firebase: {
    apiKey: 'KENDI_WEB_API_ANAHTARINIZ',
    authDomain: 'PROJENIZ.firebaseapp.com',
    databaseURL: 'https://PROJENIZ-default-rtdb.REGION.firebasedatabase.app',
    projectId: 'PROJENIZ',
    appId: 'KENDI_WEB_APP_ID'
  } */
};
